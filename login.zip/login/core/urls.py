from django.urls import path
from .views import home
from django.contrib.auth import views as auth_views
from .views import custom_logout
from . import views



urlpatterns = [
   path('', home, name='home'),
   path('accounts/logout/', custom_logout, name='logout'),
   path('registro/', views.registro, name='registro'),
]