from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login,logout
from .forms import RegistroForm
from django.contrib.auth import authenticate
from django.contrib.auth.models import User


# Create your views here.

@login_required
def home(request):
    return render(request, 'core/tarea.html')

def custom_logout(request):
    # Cerrar la sesión del usuario
    logout(request)
    # Redireccionar a la página de inicio de sesión
    return redirect('login')



def registro(request):
    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            # Crea un nuevo usuario o realiza otras acciones de registro aquí
            user = User.objects.create_user(username=username, password=password)
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('home')  # Cambia 'home' al nombre de la vista de inicio en tu proyecto
    else:
        form = RegistroForm()

    return render(request, 'registro.html', {'form': form})